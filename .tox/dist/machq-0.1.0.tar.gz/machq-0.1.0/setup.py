# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['machq', 'machq.codes', 'machq.noise', 'machq.types']

package_data = \
{'': ['*']}

install_requires = \
['black>=22.10.0,<23.0.0',
 'matplotlib>=3.6.2,<4.0.0',
 'mypy>=0.982,<0.983',
 'pandas>=1.5.1,<2.0.0',
 'pylint>=2.15.5,<3.0.0',
 'pytest-cov>=4.0.0,<5.0.0',
 'stim>=1.10.0,<2.0.0']

setup_kwargs = {
    'name': 'machq',
    'version': '0.1.0',
    'description': '',
    'long_description': 'None',
    'author': 'brendan-reid91',
    'author_email': 'brendan.reid1991@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.11',
}


setup(**setup_kwargs)
