from machq.types._stim_types import Circuit, Qubit
